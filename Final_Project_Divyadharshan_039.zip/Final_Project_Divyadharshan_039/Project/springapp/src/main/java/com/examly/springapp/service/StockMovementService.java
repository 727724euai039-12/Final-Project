package com.examly.springapp.service;

public interface StockMovementService {
    
}

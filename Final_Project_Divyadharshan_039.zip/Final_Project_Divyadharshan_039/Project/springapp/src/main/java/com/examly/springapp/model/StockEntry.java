package com.examly.springapp.model;

import jakarta.persistence.*;

@Entity
public class StockEntry {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long stockEntryId;
    
    public StockEntry() {}
    
    public Long getStockEntryId() {
        return stockEntryId;
    }
    
    public void setStockEntryId(Long stockEntryId) {
        this.stockEntryId = stockEntryId;
    }
}

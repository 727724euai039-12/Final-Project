package com.examly.springapp.controller;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/stock-movements")
public class StockMovementController {
    
    @GetMapping("/{id}")
    public String getStockMovement(@PathVariable Long id) {
        return "Stock Movement: " + id;
    }
}

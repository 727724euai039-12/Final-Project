package com.examly.springapp.service;

import org.springframework.stereotype.Service;

@Service
public class StockEntryServiceImpl implements StockEntryService {
    
}

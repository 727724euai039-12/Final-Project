package com.examly.springapp.model;

import jakarta.persistence.*;

@Entity
public class StockMovement {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long stockMovementId;
    
    public StockMovement() {}
    
    public Long getStockMovementId() {
        return stockMovementId;
    }
    
    public void setStockMovementId(Long stockMovementId) {
        this.stockMovementId = stockMovementId;
    }
}

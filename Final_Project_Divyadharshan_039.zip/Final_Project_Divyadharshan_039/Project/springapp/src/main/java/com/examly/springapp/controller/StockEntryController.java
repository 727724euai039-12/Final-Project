package com.examly.springapp.controller;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/stock-entries")
public class StockEntryController {
    
    @GetMapping("/{id}")
    public String getStockEntry(@PathVariable Long id) {
        return "Stock Entry: " + id;
    }
}

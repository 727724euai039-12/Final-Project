# e9586d3f-c766-4f4b-a2d7-8987774bc7ea-461ab1c0-49e8-4f54-a140-39fa317dac75
Repository for Teams Project code and project management
